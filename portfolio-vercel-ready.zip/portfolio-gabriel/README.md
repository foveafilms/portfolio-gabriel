# Portfolio de Gabriel Castiella

Despliegue automático en Vercel o ejecución local:
```bash
npm install
npm run dev
```